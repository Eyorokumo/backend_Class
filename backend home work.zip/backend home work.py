# Question 1
# Create variables and assign values
name = "Emmanuel Dickson"
school = "Python High School"
class_ = "Grade 10"

# Display personal details
print("Personal Details:")
print("Name:", name)
print("School:", school)
print("Class:", class_)
print("Age:", 99)

# Question 2
# Create an empty list and display it
empty_list = []
print("Empty List:", empty_list)

# Add items to the empty list
empty_list.append("item1")
empty_list.append("item2")
empty_list.append("item3")

print("Updated List:", empty_list)

# 
